Instructions for the execution of the program

Prerequired platform for the execution of this program: python3+(unix or linux)


Command to execute the code:	 python ml.py