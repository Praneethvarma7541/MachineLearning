ambition = ['high', 'medium', 'low']
programming = ['high', 'medium', 'low']
english = ['high', 'medium', 'low']
creative = ['yes', 'no']
meticulous = ['yes', 'no']

features = [ambition, programming, english, creative, meticulous]

inst1 = ['high', 'medium', 'medium', 'yes','yes']
inst2 = ['medium', 'high', 'medium', 'yes', 'yes']
inst3 = ['medium', 'medium', 'high', 'yes', 'yes']

instances = [inst1, inst2, inst3]

num_instances = 1
num_concepts = 1
for f in features:
    num_instances = num_instances * len(f)
    num_concepts = num_concepts * (len(f) + 1)

def LGG(a, b):
    common = []
    for i in range(len(a)):
        if(a[i] != b[i]):
            common.append('')
        else:
            common.append(a[i])
    return common

def LGG_Set(features, instances):
    ret = instances[0]
    for i in instances:
        ret = LGG(ret, i)
    return ret

print('LGG using algo 4.1 ')
print(LGG_Set(features, instances))

def LGG_Conj(a, b):
    for i in range(len(b)):
        if len(a) >= i + 1:
            found = False
            for x in a[i]:
                if x == b[i]:
                    found = True
                    break
            if not found:
                a[i].append(b[i])
        else:
            a.append([b[i]])
    return a

def LGG_2(features, instances):
    temp = []
    for i in instances:
        temp = LGG_Conj(temp, i)
    return temp

print('LGG using algo 4.2 ')
print(LGG_2(features, instances))
